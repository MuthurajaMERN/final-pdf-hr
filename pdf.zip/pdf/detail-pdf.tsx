import React, { useState } from "react";
import { PDFDownloadLink } from "@react-pdf/renderer";
import InvoicePDF from ".";

const InvoiceForm: React.FC = () => {
  const [invoiceDetails, setInvoiceDetails] = useState({
    invoiceNo: "",
    date: new Date().toISOString().split("T")[0],
    placeOfSupply: "",
    billTo: "",
    shipTo: "",
  });

  const [items, setItems] = useState([
    { sNo: 1, itemName: "", hsnSac: "", qty: 1, rate: 0, cgst: 5, sgst: 5 },
  ]);

  // Handle input change for invoice details
  const handleInvoiceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInvoiceDetails({ ...invoiceDetails, [e.target.name]: e.target.value });
  };

  // Handle item change
  const handleItemChange = (index: number, field: string, value: string | number) => {
    const newItems = [...items];
    (newItems[index] as any)[field] = value;
    setItems(newItems);
  };

  // Add a new item row
  const addItem = () => {
    setItems([...items, { sNo: items.length + 1, itemName: "", hsnSac: "", qty: 1, rate: 0, cgst: 5, sgst: 5 }]);
  };

  return (
    <div style={{ textAlign: "center", margin: "20px" }}>
      <h2>Invoice Generator</h2>

      {/* Invoice Details Input */}
      <div>
        <input type="text" name="invoiceNo" placeholder="Invoice No" value={invoiceDetails.invoiceNo} onChange={handleInvoiceChange} />
        <input type="date" name="date" value={invoiceDetails.date} onChange={handleInvoiceChange} />
        <input type="text" name="placeOfSupply" placeholder="Place of Supply" value={invoiceDetails.placeOfSupply} onChange={handleInvoiceChange} />
        <input type="text" name="billTo" placeholder="Bill To" value={invoiceDetails.billTo} onChange={handleInvoiceChange} />
        <input type="text" name="shipTo" placeholder="Ship To" value={invoiceDetails.shipTo} onChange={handleInvoiceChange} />
      </div>

      {/* Items Table */}
      <table border={1} style={{ margin: "20px auto", width: "80%" }}>
        <thead>
          <tr>
            <th>S.No</th>
            <th>Item Name</th>
            <th>HSN/SAC</th>
            <th>Qty</th>
            <th>Rate</th>
            <th>CGST %</th>
            <th>SGST %</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, index) => (
            <tr key={index}>
              <td>{item.sNo}</td>
              <td><input type="text" value={item.itemName} onChange={(e) => handleItemChange(index, "itemName", e.target.value)} /></td>
              <td><input type="text" value={item.hsnSac} onChange={(e) => handleItemChange(index, "hsnSac", e.target.value)} /></td>
              <td><input type="number" value={item.qty} onChange={(e) => handleItemChange(index, "qty", parseInt(e.target.value))} /></td>
              <td><input type="number" value={item.rate} onChange={(e) => handleItemChange(index, "rate", parseFloat(e.target.value))} /></td>
              <td><input type="number" value={item.cgst} onChange={(e) => handleItemChange(index, "cgst", parseFloat(e.target.value))} /></td>
              <td><input type="number" value={item.sgst} onChange={(e) => handleItemChange(index, "sgst", parseFloat(e.target.value))} /></td>
            </tr>
          ))}
        </tbody>
      </table>

      <button onClick={addItem}>Add Item</button>

      {/* PDF Download Button */}
      <PDFDownloadLink document={<InvoicePDF {...invoiceDetails} items={items} />} fileName="invoice.pdf">
        {({ loading }) => <button>{loading ? "Generating PDF..." : "Download PDF"}</button>}
      </PDFDownloadLink>
    </div>
  );
};

export default InvoiceForm;
