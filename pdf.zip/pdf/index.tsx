import { Document, Page, StyleSheet, Text, View } from '@react-pdf/renderer';
import React from 'react';

// Define styles
const styles = StyleSheet.create({
  page: { padding: 20, fontSize: 12 },
  section: { marginBottom: 10 },
  row: { flexDirection: "row", justifyContent: "space-between", marginBottom: 5 },
  title: { fontSize: 16, fontWeight: "bold" },
  text: { fontSize: 12 },
  tableHeader: {
    flexDirection: "row",
    backgroundColor: "#f2f2f2",
    padding: 5,
    fontWeight: "bold",
  },
  tableRow: {
    flexDirection: "row",
    borderBottomWidth: 1,
    borderBottomColor: "#ddd",
    paddingVertical: 5,
  },
  cell: { flex: 1, textAlign: "center", padding: 2 },
  totalRow: { flexDirection: "row", justifyContent: "flex-end", marginTop: 10 },
});

interface InvoiceProps {
  invoiceNo: string;
  date: string;
  placeOfSupply: string;
  billTo: string;
  shipTo: string;
  items: {
    sNo: number;
    itemName: string;
    hsnSac: string;
    qty: number;
    rate: number;
    cgst: number;
    sgst: number;
  }[];
}

// PDF Component
const InvoicePDF: React.FC<InvoiceProps> = ({
  invoiceNo,
  date,
  placeOfSupply,
  billTo,
  shipTo,
  items,
}) => {
  // Calculate total amounts
  const totalCGST = items.reduce((acc, item) => acc + (item.rate * item.qty * item.cgst) / 100, 0);
  const totalSGST = items.reduce((acc, item) => acc + (item.rate * item.qty * item.sgst) / 100, 0);
  const grandTotal = items.reduce((acc, item) => acc + item.rate * item.qty, 0) + totalCGST + totalSGST;

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Invoice Header */}
        <View style={styles.section}>
          <View style={styles.row}>
            <Text style={styles.title}>Invoice No: {invoiceNo}</Text>
            <Text style={styles.title}>Date: {date}</Text>
          </View>
          <Text>Place of Supply: {placeOfSupply}</Text>
        </View>

        {/* Billing Details */}
        <View style={styles.section}>
          <View style={styles.row}>
            <View>
              <Text style={styles.title}>Bill To:</Text>
              <Text>{billTo}</Text>
            </View>
            <View>
              <Text style={styles.title}>Ship To:</Text>
              <Text>{shipTo}</Text>
            </View>
          </View>
        </View>

        {/* Items Table */}
        <View style={styles.section}>
          <View style={styles.tableHeader}>
            <Text style={[styles.cell, { flex: 0.5 }]}>S.No</Text>
            <Text style={styles.cell}>Item</Text>
            <Text style={styles.cell}>HSN/SAC</Text>
            <Text style={styles.cell}>Qty</Text>
            <Text style={styles.cell}>Rate</Text>
            <Text style={styles.cell}>CGST (%)</Text>
            <Text style={styles.cell}>SGST (%)</Text>
            <Text style={styles.cell}>Amount</Text>
          </View>
          {items.map((item, index) => (
            <View key={index} style={styles.tableRow}>
              <Text style={[styles.cell, { flex: 0.5 }]}>{item.sNo}</Text>
              <Text style={styles.cell}>{item.itemName}</Text>
              <Text style={styles.cell}>{item.hsnSac}</Text>
              <Text style={styles.cell}>{item.qty}</Text>
              <Text style={styles.cell}>{item.rate.toFixed(2)}</Text>
              <Text style={styles.cell}>{item.cgst}%</Text>
              <Text style={styles.cell}>{item.sgst}%</Text>
              <Text style={styles.cell}>
                {(item.rate * item.qty + (item.rate * item.qty * (item.cgst + item.sgst)) / 100).toFixed(2)}
              </Text>
            </View>
          ))}
        </View>

        {/* Totals */}
        <View style={styles.totalRow}>
          <Text style={styles.text}>Total CGST: ₹{totalCGST.toFixed(2)}</Text>
        </View>
        <View style={styles.totalRow}>
          <Text style={styles.text}>Total SGST: ₹{totalSGST.toFixed(2)}</Text>
        </View>
        <View style={styles.totalRow}>
          <Text style={[styles.title, { fontSize: 14 }]}>Grand Total: ₹{grandTotal.toFixed(2)}</Text>
        </View>
      </Page>
    </Document>
  );
};

export default InvoicePDF;
